//
//  TRImageView.h
//  BaseProject
//
//  Created by tarena-ZeRO on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyImageView : UIView
@property(nonatomic,strong)UIImageView *imageView;
@end
