//
//  HappyCell.h
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HappyCell : UITableViewCell
@property(nonatomic,strong)UILabel *textLB;
@property(nonatomic,strong)UIView *lineView;
@property(nonatomic,strong)UIButton *CategoryBtn;
@property(nonatomic,strong)UILabel *commentLB;
@property(nonatomic,strong)UIImageView *img1;

@end
