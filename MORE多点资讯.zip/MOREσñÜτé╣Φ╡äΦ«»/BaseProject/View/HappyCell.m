//
//  HappyCell.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HappyCell.h"

@implementation HappyCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //设置cell被选中后的背景色
        UIView *view=[UIView new];
        view.backgroundColor=kRGBColor(243, 255, 254);
        self.selectedBackgroundView=view;
        
    }
    return self;
}
-(UILabel *)textLB{
    if (!_textLB) {
        _textLB=[UILabel new];
        [self.contentView addSubview:_textLB];
        [_textLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.bottom.mas_equalTo(-35);
        }];
        _textLB.font=[UIFont systemFontOfSize:12];
        _textLB.numberOfLines=0;
    }
    return _textLB;
}
-(UIView *)lineView{
    if (!_lineView) {
        _lineView=[UIView new];
        [self.contentView addSubview:_lineView];
        _lineView.backgroundColor=[UIColor orangeColor];
        [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(0);
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(0);
            make.height.mas_equalTo(1);
        }];
    }
    return _lineView;
}
-(UIButton *)CategoryBtn{
    if (!_CategoryBtn) {
        _CategoryBtn=[UIButton buttonWithType:0];
        _CategoryBtn.backgroundColor=kRGBColor(224, 179, 186);
        [_CategoryBtn setTitleColor:[UIColor grayColor] forState:0];
        [self.contentView addSubview:_CategoryBtn];
        _CategoryBtn.layer.cornerRadius=10;
        [self.contentView.layer addSublayer:_CategoryBtn.layer];
        _CategoryBtn.titleLabel.font=[UIFont systemFontOfSize:10];
        [_CategoryBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(self.textLB.mas_bottom).mas_equalTo(5);
            make.size.mas_equalTo(CGSizeMake(80, 20));
        }];
    }
    return _CategoryBtn;
}
-(UILabel *)commentLB{
    if (!_commentLB) {
        _commentLB=[UILabel new];
        [self.contentView addSubview:_commentLB];
        _commentLB.font=[UIFont systemFontOfSize:9];
        _commentLB.textColor=[UIColor lightGrayColor];
        [_commentLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(0);
            make.top.mas_equalTo(self.CategoryBtn.mas_top).mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(30, 20));
        }];
    }
    return _commentLB;
}
-(UIImageView *)img1{
    if (!_img1) {
        _img1=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"comment"]];
        [self.contentView addSubview:_img1];
        [_img1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.commentLB.mas_left).mas_equalTo(-5);
            make.top.mas_equalTo(self.CategoryBtn.mas_top).mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(15, 15));
        }];
    }
    return _img1;
}

@end
