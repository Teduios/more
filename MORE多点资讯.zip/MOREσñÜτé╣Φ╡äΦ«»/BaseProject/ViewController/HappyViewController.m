//
//  ViewController.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HappyViewController.h"
#import "HappyViewModel.h"
#import "HappyCell.h"
@interface HappyViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableview;
@property(nonatomic,strong)HappyViewModel *hVM;
@end

@implementation HappyViewController
-(HappyViewModel *)hVM{
    if (!_hVM) {
        _hVM=[HappyViewModel new];
    }
    return _hVM;
}
-(UITableView *)tableview{
    if (!_tableview) {
        _tableview=[[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableview.delegate=self;
        _tableview.dataSource=self;
        [self.view addSubview:_tableview];
        [_tableview mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
        _tableview.mj_header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
           [self.hVM refreshDataCompletionHandle:^(NSError *error) {
               [_tableview.mj_header endRefreshing];
               [_tableview reloadData];
           }];
        }];
        _tableview.mj_footer=[MJRefreshBackNormalFooter  footerWithRefreshingBlock:^{
            [self.hVM getMoreDataCompletionHandle:^(NSError *error) {
                [_tableview.mj_footer beginRefreshing];
                [_tableview reloadData];
                [_tableview.mj_footer endRefreshing];
            }];
        }];
    }
    return _tableview;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableview registerClass:[HappyCell class] forCellReuseIdentifier:@"Cell"];
    [self.tableview.mj_header beginRefreshing];
}
#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.hVM.rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HappyCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    if ([self.hVM categorForRow:indexPath.row]==nil) {
        cell.textLB.text=[self.hVM contentForRow:1];
        [cell.CategoryBtn setTitle:[self.hVM categorForRow:1] forState:0];
    }else{
    cell.textLB.text=[self.hVM contentForRow:indexPath.row];
    cell.lineView.alpha=0.9;
    [cell.CategoryBtn setTitle:[self.hVM categorForRow:indexPath.row] forState:0];
    cell.commentLB.text=[self.hVM commentCountForRow:indexPath.row];
    cell.img1.alpha=0.9;
    }
    
    return cell;
    
}
kRemoveCellSeparator
-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 0;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


@end
