//
//  WelcomeViewController.h
//  欢迎界面
//
//  Created by xiaoz on 15/9/10.
//  Copyright (c) 2015年 xiaoz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WelcomeViewController : UIViewController

@end
