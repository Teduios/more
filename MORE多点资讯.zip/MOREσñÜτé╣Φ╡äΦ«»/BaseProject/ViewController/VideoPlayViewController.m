//
//  VideoPlayViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoPlayViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
//#import "FlatUIKit.h"
@interface VideoPlayViewController ()
@property(nonatomic,strong)UIButton *playButton;
@property(nonatomic,strong)FUIButton *pauseButton;
@property(nonatomic,strong)FUIButton *continueButton;
@property(nonatomic,strong)UILabel *descLabel;
@property(nonatomic,strong) AVPlayerLayer *layer;
@property(nonatomic,strong)AVPlayer *player;
@end

@implementation VideoPlayViewController
-(id)initWithPlayURL:(NSURL *)url andDescription:(NSString *)desc{
    if (self=[super init]) {
        self.url=url;
        self.desc=desc;
    }
    return self;
}
-(FUIButton *)pauseButton{
    if (!_pauseButton) {
        _pauseButton=[FUIButton buttonWithType:0];
        _pauseButton.buttonColor = [UIColor turquoiseColor];
        _pauseButton.shadowColor = [UIColor greenSeaColor];
        _pauseButton.shadowHeight = 4.0f;
        _pauseButton.cornerRadius = 6.0f;
        _pauseButton.titleLabel.font = [UIFont boldFlatFontOfSize:18];
        [_pauseButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
        [_pauseButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
        [self.view addSubview:_pauseButton];
        [_pauseButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.descLabel.mas_bottom).mas_equalTo(20);
            make.left.mas_equalTo(kWindowW/5);
            make.width.mas_equalTo(kWindowW/5);
        }];
    }
    return _pauseButton;
}
-(FUIButton *)continueButton{
    if (!_continueButton) {
        _continueButton=[FUIButton buttonWithType:0];
        _continueButton=[FUIButton buttonWithType:0];
        _continueButton.buttonColor = [UIColor turquoiseColor];
        _continueButton.shadowColor = [UIColor greenSeaColor];
        _continueButton.shadowHeight = 4.0f;
        _continueButton.cornerRadius = 6.0f;
        _continueButton.titleLabel.font = [UIFont boldFlatFontOfSize:18];
        [_continueButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
        [_continueButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
        [self.view addSubview:_continueButton];
        [_continueButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.descLabel.mas_bottom).mas_equalTo(20);
            make.right.mas_equalTo(-kWindowW/5);
            make.width.mas_equalTo(kWindowW/5);
        }];
    }
    return _continueButton;
}
-(UIButton *)playButton{
    if (!_playButton) {
        _playButton=[UIButton buttonWithType:0];
        [_playButton setBackgroundImage:[UIImage imageNamed:@"play"] forState:0];
        [self.view addSubview:_playButton];
        [_playButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(kWindowW-20);
            make.height.mas_equalTo((kWindowW-20)*190/280);
            make.centerX.mas_equalTo(0);
            make.top.mas_equalTo(90);
        }];
    }
    return _playButton;
}
-(UILabel *)descLabel{
    if (!_descLabel) {
        _descLabel=[[UILabel alloc]init];
        _descLabel.text=self.desc;
        [self.view addSubview:_descLabel];
        _descLabel.font=[UIFont systemFontOfSize:18];
        _descLabel.textAlignment=NSTextAlignmentLeft;
        _descLabel.numberOfLines=0;
        [_descLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(20);
            make.right.mas_equalTo(-20);
            make.top.mas_equalTo(self.playButton.mas_bottom).mas_equalTo(30);
        }];
    }
    return _descLabel;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:self.playButton];
    [self.view addSubview:self.descLabel];
    [self.view addSubview:self.pauseButton];
    [self.view addSubview:self.continueButton];
    self.title=@"视频播放";
    [self.pauseButton setTitle:@"暂停" forState:0];
    [self.continueButton setTitle:@"播放" forState:0];
    self.player=[AVPlayer playerWithURL:self.url];
    self.layer=[AVPlayerLayer playerLayerWithPlayer:self.player];
    [self.playButton bk_addEventHandler:^(id sender) {
        [self.playButton setBackgroundImage:[UIImage imageNamed:@"bg"] forState:0];
        [self.layer removeFromSuperlayer];
        self.layer.frame=self.playButton.frame;
        [self.view.layer addSublayer:self.layer];
        [self.player play];
    } forControlEvents:UIControlEventTouchUpInside];
    [self.pauseButton bk_addEventHandler:^(id sender) {
        [self.player pause];
    } forControlEvents:UIControlEventTouchUpInside];
    [self.continueButton bk_addEventHandler:^(id sender) {
        [self.playButton setBackgroundImage:[UIImage imageNamed:@"b"] forState:0];
        self.layer.frame=self.playButton.frame;
        [self.view.layer addSublayer:self.layer];
        [self.player play];
    } forControlEvents:UIControlEventTouchUpInside];
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [self.player pause];
    [self.view removeFromSuperview];
    self.player=nil;
}
@end

