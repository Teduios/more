//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "WelcomeViewController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //    [NSThread sleepForTimeInterval:2.0];
    NSDictionary *infodict=[[NSBundle mainBundle]infoDictionary];
    /*版本号
     version:正式发布版本号，用户只能看到version
     build：测试版本号，对于程序员来说的
     */
    NSLog(@"%@",infodict);
    NSString *key=@"CFBundleShortVersionString";
    NSString *currentVersion=infodict[key];
    //已运行过的版本号需要持久化处理，通常存在userdefault中
    NSString *runVersion=[[NSUserDefaults standardUserDefaults]stringForKey:key];
    if (runVersion==nil||![runVersion isEqualToString:currentVersion]) {
        //没运行过 或者版本号不一致，则显示欢迎页
        self.window = [[UIWindow alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
        self.window.rootViewController=[[WelcomeViewController alloc]init];
        [self.window makeKeyAndVisible];
        //保存新的版本号，防止下次运行再显示欢迎页
        [[NSUserDefaults standardUserDefaults]setObject:currentVersion forKey:key];
    }
    else{
        NSLog(@"显示主界面");
    }

    [self initializeWithApplication:application];

    return YES;
}

@end
