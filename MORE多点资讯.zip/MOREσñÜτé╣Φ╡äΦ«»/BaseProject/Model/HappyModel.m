//
//  HappyModel.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HappyModel.h"

@implementation HappyModel

@end
@implementation HappyData

+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [HapppyDataData class]};
}

@end


@implementation HapppyDataData

+ (NSDictionary *)objectClassInArray{
    return @{@"comments" : [HappyDataDataComments class]};
}

@end


@implementation HappyDataDataGroup

+ (NSDictionary *)objectClassInArray{
    return @{@"dislike_reason" : [HappyDataDataGroupDislike_Reason class]};
}

@end


@implementation HappyDataDataGroupActivity

@end


@implementation HappyDataDataGroupUser

@end


@implementation HappyDataDataGroupNeihan_Hot_Link

@end


@implementation HappyDataDataGroupDislike_Reason

@end


@implementation HappyDataDataComments

@end


