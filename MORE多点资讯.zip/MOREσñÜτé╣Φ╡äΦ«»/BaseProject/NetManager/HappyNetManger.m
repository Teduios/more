//
//  HappyNetManger.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HappyNetManger.h"

@implementation HappyNetManger
+(id)getHappyPathWithPage:(NSInteger)page completionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *path=[NSString stringWithFormat:@"http://ic.snssdk.com/neihan/stream/mix/v%ld/?content_type=-102&iid=3224666765&os_version=9.1&os_api=18&app_name=joke_essay&channel=App%%20Store&device_platform=iphone&idfa=idfa&vid=748A1989-3B59-43D4-9888-AF2560DAA069&openudid=e8f377eebaeaf64b5d6d9586f3c0cc6240dc8656&device_type=iPhone%%205S&version_code=4.4.2&ac=WIFI&screen_width=640&device_id=7684046598&aid=7&content_type=-102&count=30&essence=1&message_cursor=0&mpic=1",page];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([HappyModel objectWithKeyValues:responseObj],error);
    }];
}
@end
