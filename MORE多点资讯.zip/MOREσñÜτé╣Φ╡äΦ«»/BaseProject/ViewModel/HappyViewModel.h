//
//  HappyViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "HappyNetManger.h"
@interface HappyViewModel : BaseViewModel
@property(nonatomic,assign)NSInteger rowNumber;
@property(nonatomic,assign)NSInteger page;
-(NSString *)contentForRow:(NSInteger)row;
-(NSString *)categorForRow:(NSInteger)row;
-(NSString *)commentCountForRow:(NSInteger)row;
-(NSString *)favorCountForRow:(NSInteger)row;
@end
