//
//  HappyViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HappyViewModel.h"

@implementation HappyViewModel
-(NSInteger)rowNumber{
    return self.dataArr.count;
}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _page=1;
    [self getDataFromNetCompleteHandle:completionHandle];

}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _page+=1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask=[HappyNetManger getHappyPathWithPage:_page completionHandle:^(HappyModel *model, NSError *error) {
        if (_page==1) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.data.data];
        completionHandle(error);
    }];
}
-(HapppyDataData *)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}
-(NSString *)contentForRow:(NSInteger)row{
    return [self modelForRow:row].group.content;
}
-(NSString *)categorForRow:(NSInteger)row{
    return [self modelForRow:row].group.category_name;
}
-(NSString *)commentCountForRow:(NSInteger)row{
    return @([self modelForRow:row].group.comment_count).stringValue;
}
@end
